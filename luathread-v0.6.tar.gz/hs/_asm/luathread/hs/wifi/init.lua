--- === hs.wifi ===
---
--- Inspect WiFi networks

local wifi = require "hs.wifi.internal"
wifi.watcher = require "hs.wifi.watcher"

return wifi
